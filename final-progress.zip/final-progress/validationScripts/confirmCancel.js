//updateValidation.js
function confirmCancel()
{
	var cancel = confirm("are you sure you want to cancel this invoice?");
	return cancel;
}