//addAccountValidation.js

function validInput()
{
	return;
}